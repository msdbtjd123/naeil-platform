#!/bin/python3

import os,sys,subprocess
from threading import Thread

openrc_file = f"admin_{sys.argv[1]}rc"

auth_url = subprocess.getstatusoutput(f"grep -i 'export os_auth_url' /capstone.d/openrc.d/{openrc_file}.sh | cut -f2 -d'=' | tr -d '\"' ")[1]
project_name = subprocess.getstatusoutput(f"grep -i 'export os_project_name' /capstone.d/openrc.d/{openrc_file}.sh | cut -f2 -d'=' | tr -d '\"' ")[1]
user_domain_name = subprocess.getstatusoutput(f"grep -i 'export os_user_domain_name' /capstone.d/openrc.d/{openrc_file}.sh | cut -f2 -d'=' | tr -d '\"' ")[1]
project_domain_id = subprocess.getstatusoutput(f"grep -i 'export os_project_domain_id' /capstone.d/openrc.d/{openrc_file}.sh | cut -f2 -d'=' | tr -d '\"' ")[1]
username = subprocess.getstatusoutput(f"grep -i 'export os_username' /capstone.d/openrc.d/{openrc_file}.sh | cut -f2 -d'=' | tr -d '\"' ")[1]
password = subprocess.getstatusoutput(f"grep -i 'export os_password' /capstone.d/openrc.d/{openrc_file}.sh | cut -f2 -d'=' | tr -d '\"' ")[1]


project_id = subprocess.getstatusoutput(f"grep -i 'export os_project_id' /capstone.d/openrc.d/{openrc_file}.sh | cut -f2 -d'=' | tr -d '\"' ")[1]

os.environ['OS_AUTH_URL']=auth_url
os.environ['OS_PROJECT_NAME']=project_name
os.environ['OS_USER_DOMAIN_NAME']=user_domain_name
os.environ['OS_PROJECT_DOMAIN_ID']=project_domain_id
os.environ['OS_USERNAME']=username
os.environ['OS_PASSWORD']=password

class get_vnc_url(Thread) :
	def __init__(self,instance_id,os) :
		Thread.__init__(self)
		
		self.instance_id=instance_id
		self.instance_os=os

	def run(self) :
		def instance_get_vnc_url(self,cmd) :
			#print(cmd)
			instance_url=subprocess.getstatusoutput(cmd)[1]
			print(self.instance_os+","+instance_url)

		cmd = (f"openstack console url show {self.instance_id} | grep url | cut -f3 -d'|' | tr -d ' '")
		Thread(target=instance_get_vnc_url, args=(self,cmd)).start()

if sys.argv[1] == "admin" :
	instances_id=subprocess.getstatusoutput(f"mysql nova -u nova -p'5aa13c9a9ddb4a37' -e \"SELECT ifnull(display_description,'None'),uuid FROM instances WHERE deleted='0'\" | grep -v uuid")[1].split()
else :
	instances_id=subprocess.getstatusoutput(f"mysql nova -u nova -p'5aa13c9a9ddb4a37' -e \"SELECT ifnull(display_description,'None'),uuid FROM instances WHERE deleted='0' AND project_id = '{project_id}'\" | grep -v uuid")[1].split()

dict_instance = dict(zip(instances_id[1::2], instances_id[0::2]))

for instance_id,os in dict_instance.items() :
	get_vnc_url(instance_id,os).start()
