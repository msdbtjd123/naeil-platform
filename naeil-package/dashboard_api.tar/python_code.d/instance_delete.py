import subprocess,os,sys

### Instance information to be deleted ###
openrc_file = sys.argv[1]
instance_name = sys.argv[2].replace(","," ")
######################################

auth_url = subprocess.getstatusoutput(f"grep -i 'export os_auth_url' /capstone.d/openrc.d/{openrc_file}.sh | cut -f2 -d'=' | tr -d '\"' ")[1]
project_name = subprocess.getstatusoutput(f"grep -i 'export os_project_name' /capstone.d/openrc.d/{openrc_file}.sh | cut -f2 -d'=' | tr -d '\"' ")[1]
user_domain_name = subprocess.getstatusoutput(f"grep -i 'export os_user_domain_name' /capstone.d/openrc.d/{openrc_file}.sh | cut -f2 -d'=' | tr -d '\"' ")[1]
project_domain_id = subprocess.getstatusoutput(f"grep -i 'export os_project_domain_id' /capstone.d/openrc.d/{openrc_file}.sh | cut -f2 -d'=' | tr -d '\"' ")[1]
username = subprocess.getstatusoutput(f"grep -i 'export os_username' /capstone.d/openrc.d/{openrc_file}.sh | cut -f2 -d'=' | tr -d '\"' ")[1]
password = subprocess.getstatusoutput(f"grep -i 'export os_password' /capstone.d/openrc.d/{openrc_file}.sh | cut -f2 -d'=' | tr -d '\"' ")[1]


os.environ['OS_AUTH_URL']=auth_url
os.environ['OS_PROJECT_NAME']=project_name
os.environ['OS_USER_DOMAIN_NAME']=user_domain_name
os.environ['OS_PROJECT_DOMAIN_ID']=project_domain_id
os.environ['OS_USERNAME']=username
os.environ['OS_PASSWORD']=password


os.system(f"openstack instance delete {instance_name}")
#print(f"openstack instance delete {instance_name}")

